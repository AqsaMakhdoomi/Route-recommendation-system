The GNN-model is taken from the following paper
Passenger Mobility Prediction via Representation Learning
for Dynamic Directed and Weighted Graph
(https://arxiv.org/pdf/2101.00752.pdf)